let json = {
  "type": "service_account",
  "project_id": "coderback-fbb85",
  "private_key_id": "f524c497fdd6bbae749229e9c84411ac14215169",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCfg1Nh31GFS7Do\nt2GT4OB+dqGDyPPxAHVUly7JYHcMb/UyJSNbQqIY7z9HmDSOX+EIjsZTWrINyxd9\nG5kTyQC6XaFQ7sEGmtHw8APqngAScDidHl6vrkyH8oMTptMOMr05EVpjXlFuLVKK\n2uzxKPPhrgnd2rnNNHqtxu6PHNgxlll8UtvVl67NcprpqnbDBlGaxoO4HqDfivMa\n8hpiq8sxNen1BO3Fm/DMbAP9K38gxlL0Wp7xB5/YLQATtRmqcniR7nZpBsqePDBV\nigHheir1ig/gN7wqv+EbaShE8Xk18QhYW413Cg/veW02BDVWIIhw3VMGOO4f5RtK\nYK4nDe7PAgMBAAECggEATFkHJ+lDk5FO85QSWD1iNiWB2Rnt6IRXpE1YT3qkgId1\nzLKJ4bxa6aRZnWL0hNDPXNE5i9v1LTTv4Sm8cwPaHVmDRMGCEi84HSJEPZ+yWSDt\neAZ5O40phEhHBLjse/c9Kntrz/Ps9dcrktqGXkdDs9khT9bI57ceoN5+gHFF6TVT\nk6cZIz7MdE5CvmnHo3bQv5GgDtMv4PonVpXrUr7lJJi5TaJVqjt0BdHvDq05RAyp\nHKkDA0epm/GS+tIibOKLX4uBVWAdRN0mEXAj1bIl6AoHJdTwW5PpoFUUf64XEjjw\nTxZ1wm7yCYfylA5OyYQwnYzy/Zz3nZS3sy14Y4H7AQKBgQDVcgJ5qTYQ7S5cdxSd\nT92nco8RWwexI/yotCkZMJMv9U1oTHSEaXDly/KVJCISBVX8JhMsL6UE32rlqhtj\nHlE/gFEUVskSS07th3QCp7bghqydZIdLHKajUg17OedMHxhNvKUMZGJAZPTYc+Hb\nQIw3ypnsBHAtoAK8fl1gIUEEUQKBgQC/UKyZMXlzJsHNp5BAG3zajL41DZsXyVC4\nV8p9ocnNiy/ij7lzo3SCA5/6sV8FashOokG0mPL8WqqblaEMR8vjMjQQYw7BW8lT\n7CI6dfnonJF09x5F9bX1efoHXWn3ScW1g/UkfDCvrQox8VTMJXxWHpyVV3G+Y7WJ\n44pLVnqZHwKBgEkAsIYJ8NsDNDsd42gWm9ocnYAzIUNd6pmM3Q2nhn/9p1cH50Yu\nhhWilrqZ3ClLt+gA4cfYF9m9zGL2tl1FTkaozZJmSGlAZqNpE62gzTSn+zvt2TRA\nfWIYu1GtMUXg0MAtyEmfv9cEcJXjtJj3z715RwHpVrDULHtpwOgTF5ixAoGACiTp\n8fmImg19Cz2OTYfnl+MMlt2Q0rMO/6dQCldQzwBJWrcKO1J4dAhjLDTJeA0Qb/L0\njvHpOG5KS5OkhXUtH2/jCNdnyeLnCvcjXXwx8x6SK+SKi2Ua79g25LsUSlN0E0ra\n7cNUBYykVL+aInT+YcafwN9xHYpF7vjMtW/xcjsCgYEAkqDxcKQovuNUo3HUGNiY\nJJrXUZx99Gjx6WKfqjt+Uk3Px3zAdB7NR/PvXd9H6gOTkjyMwRzuKBBASNiIyTNN\nDeCYIS7kyyxHqJnwNHCklO5D+kYMKqVRLEGe1r2X6fELWUT29sx7ahs9omJrhjVU\n/MbRzJyES3H/bFd8QeRjS9o=\n-----END PRIVATE KEY-----\n",
  "client_email": "firebase-adminsdk-lmr3o@coderback-fbb85.iam.gserviceaccount.com",
  "client_id": "112618465961581503656",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-lmr3o%40coderback-fbb85.iam.gserviceaccount.com"
}

export default json;
